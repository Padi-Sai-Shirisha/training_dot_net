﻿using StudentEx.Models;

namespace StudentEx.Models
{
    public class Student
    {
        public string name { get; set; }
        public int id { get; set; }
        public string course { get; set; }
        public int years { get; set; }
        public string date { get; set; }
        public int fees { get; set; }

        public Student(string name, int id, string course, int years, string date, int fees)
        {
            this.name = name;
            this.id = id;
            this.course = course;
            this.years = years;
            this.date = date;
            this.fees = fees;
        }

        public Student() { }

        public override string ToString()
        {
            return "\nStudent: " + name + " with id: " + id + " course: "+ course;
        }
    }
}

